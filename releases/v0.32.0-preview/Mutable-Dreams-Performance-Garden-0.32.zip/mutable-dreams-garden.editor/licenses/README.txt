Mutable Dreams · Performance Garden – firmware for VIBE FM, by Kid Bunka. Licence: GPL-3.0-only (GPL-3.0.txt).
The complete corresponding source code is offered together with each release of this firmware: a source tree
that builds this exact file byte for byte (README.md in it says how). Ask the author if you did not receive it.

Inside: the Mutable Dreams engine (GPL-3.0-only; MIT-Mutable-Dreams.txt for its MIT-licensed parts),
Mutable Instruments DSP code (MIT, MIT-Mutable-Instruments.txt), platform headers (MPL-2.0, MPL-2.0-base.txt),
the VIBE FM SDK (Apache-2.0, Apache-2.0-VIBE-FM-SDK.txt and NOTICE-VIBE-FM-SDK.txt; its fonts:
LICENSE-FONTS-VIBE-FM-SDK.txt), the Editor page's fonts Nunito and Barlow Semi Condensed (SIL OFL 1.1, ../fonts/).
"VIBE FM" is a trademark of its owner; this firmware is built with the VIBE FM SDK.
